package com.example.customermanagement.controller;

	import java.util.List;

import javax.validation.Valid;

import org.hibernate.annotations.common.util.StringHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.CrossOrigin;
	import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

import com.example.customermanagement.dto.CustomerDto;
import com.example.customermanagement.entity.Customer;
import com.example.customermanagement.exception.CustomerNotFoundException;
import com.example.customermanagement.exception.InvalidFieldException;
import com.example.customermanagement.mapstruct.MapstructMapper;
import com.example.customermanagement.service.ICustomerService;

	
    @ControllerAdvice
	@RequestMapping(value="/customer")
	@RestController
	@CrossOrigin(value="*")
    @EnableFeignClients
	public class CustomerController {
		
		@Autowired
		private ICustomerService service;
		@Autowired
		private MapstructMapper mapstruct;
		private final Logger logger = LoggerFactory.getLogger(CustomerController.class);
	    @RequestMapping("/")
	    String controller(){
	        logger.info("This is a customer management controller layer");
	        return "controller";
	    }
		@GetMapping(value="/getAll")
		public ResponseEntity<List<Customer>> getAllCustomers()
		{
			List<Customer> getAllCustomers=service.getAllCustomers();
			
			return new ResponseEntity<>(getAllCustomers,HttpStatus.OK);
		}
		
		@GetMapping(value="/{cid}")
		public ResponseEntity<Customer> getCustomer(@PathVariable Integer cid)
		{
			Customer customer=service.getCustomer(cid);
			if(customer.getCid()==cid) {
				return new ResponseEntity<Customer>(customer,HttpStatus.OK);
			}
			else {
				throw new CustomerNotFoundException("Customer not found");
			}
		}
		
		@PostMapping(value="/save")
		public ResponseEntity<Customer> savecustomer(@Valid @RequestBody CustomerDto customer)
		{
		Customer savecustomer =mapstruct.customerDtoToCustomer(service.addCustomer(customer));
		logger.info("saved details");
		
		 if(customer.getCity()==null) {
			 throw new InvalidFieldException("City is required");
		 }
		 return new ResponseEntity<Customer>(savecustomer, HttpStatus.CREATED);
		}
		
		@ExceptionHandler
		public String handleInvalidFieldException(InvalidFieldException exception) {
			return exception.getMessage();
		}
		
		
		@DeleteMapping("/customer/{id}")
		public void delete(@PathVariable Integer id) {
			 service.delete(id);
		}

	}



