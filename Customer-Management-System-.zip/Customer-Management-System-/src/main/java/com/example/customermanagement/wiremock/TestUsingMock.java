/*package com.example.customermanagement.wiremock;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;

//import io.restassured.RestAssured;

//import com.github.tomakehurst.wiremock.WireMockServer;

import io.restassured.RestAssured;



public class TestUsingMock {
	
	private static final int PORT=8080;
	private static final String HOST="localhost";
	private static WireMockServer server=new WireMockServer(PORT);
	
	@BeforeClass
	public static void setup() {
		server.start();
		
		ResponseDefinitionBuilder mockResponse=new ResponseDefinitionBuilder();
		mockResponse.withStatus(200);
		WireMock.configureFor(HOST,PORT);
		WireMock.stubFor(
				WireMock.get("http://localhost:8080/customer/getAll"));
		
	}
	
	@Test
	public void TestGetEndPoint()throws URISyntaxException{
		RestAssured.given()
		.when()
		.get(new URI("http://localhost:8080/customer/getAll"))
		.then()
		.assertThat()
		.statusCode(200);
		
	}
	
	@AfterClass
	public static void teardown() {
		if(null!=server && server.isRunning()) {
			server.shutdownServer();
		}
	}
	
}
*/